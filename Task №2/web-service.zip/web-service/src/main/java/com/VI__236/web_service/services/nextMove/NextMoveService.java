package com.VI__236.web_service.services.nextMove;

import com.VI__236.web_service.dto.BoardDto;
import com.VI__236.web_service.dto.SimpleMoveDto;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
@Async
public interface NextMoveService {
    SimpleMoveDto nextMove(BoardDto boardDto);
}
