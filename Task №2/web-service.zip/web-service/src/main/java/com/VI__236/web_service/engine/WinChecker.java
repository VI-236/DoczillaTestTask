package com.VI__236.web_service.engine;

import com.VI__236.web_service.models.GameBoard;
import org.springframework.stereotype.Component;

@Component
public class WinChecker {
    private boolean win = false;
    private IsValidMove moveChecker = new IsValidMove();

    public boolean winChek(int coordinateX, int coordinateY, GameBoard gameBoard){

        System.out.println("Enter coordinate Х: " + coordinateX);
        System.out.println("Enter coordinate Y: " + coordinateY);
        char [][] temporaryBoard = gameBoard.getBoard();

        char colorOfCell = temporaryBoard[coordinateX][coordinateY];

        //Small square checker:
        //_ _ _ _ _
        //_ _ o o _
        //_ _ o o _
        //_ _ _ _ _
        try{
            System.out.println("Start small square checker 1");
            if (moveChecker.moveValidator(coordinateX, coordinateY + 1, gameBoard) &&
                    temporaryBoard[coordinateX][coordinateY + 1] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX + 1, coordinateY + 1, gameBoard) &&
                    temporaryBoard[coordinateX + 1][coordinateY + 1] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX + 1, coordinateY, gameBoard) &&
                    temporaryBoard[coordinateX + 1][coordinateY] == colorOfCell) {
                System.out.println("The small square is found.");
                return win = true;
            }
            System.out.println("Finish small square checker 1");
            System.out.println(" ");
            System.out.println("Start small square checker 2");
            if (moveChecker.moveValidator(coordinateX + 1, coordinateY, gameBoard) &&
                    temporaryBoard[coordinateX + 1][coordinateY] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX + 1, coordinateY - 1, gameBoard) &&
                    temporaryBoard[coordinateX + 1][coordinateY - 1] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX, coordinateY - 1, gameBoard) &&
                    temporaryBoard[coordinateX][coordinateY - 1] == colorOfCell) {
                System.out.println("The small square is found.");
                return win = true;
            }
            System.out.println("Finish small square checker 2");
            System.out.println(" ");
            System.out.println("Start small square checker 3");
            if (moveChecker.moveValidator(coordinateX, coordinateY - 1, gameBoard) &&
                    temporaryBoard[coordinateX][coordinateY - 1] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX - 1, coordinateY - 1, gameBoard) &&
                    temporaryBoard[coordinateX - 1][coordinateY - 1] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX - 1, coordinateY, gameBoard) &&
                    temporaryBoard[coordinateX - 1 ][coordinateY] == colorOfCell) {
                System.out.println("The small square is found.");
                return win = true;
            }
            System.out.println("Finish small square checker 3");
            System.out.println(" ");
            System.out.println("Start small square checker 4");
            if (moveChecker.moveValidator(coordinateX - 1, coordinateY, gameBoard) &&
                    temporaryBoard[coordinateX - 1][coordinateY] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX - 1, coordinateY + 1, gameBoard) &&
                    temporaryBoard[coordinateX - 1][coordinateY + 1] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX, coordinateY + 1, gameBoard) &&
                    temporaryBoard[coordinateX][coordinateY + 1] == colorOfCell) {
                System.out.println("The small square is found.");
                return win = true;
            }
            System.out.println("Finish small square checker 4");
            System.out.println("----------------------------------------------------------");

            //Big square checker:
            //_ _ _ _ _
            //_ o _ o _
            //_ _ _ _ _
            //_ o _ o _
            //_ _ _ _ _
            System.out.println("Start big square checker 1");
            if (moveChecker.moveValidator(coordinateX, coordinateY  + 2, gameBoard) &&
                    temporaryBoard[coordinateX][coordinateY  + 2] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX + 2, coordinateY + 2, gameBoard) &&
                    temporaryBoard[coordinateX + 2][coordinateY + 2] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX  + 2, coordinateY, gameBoard) &&
                    temporaryBoard[coordinateX  + 2][coordinateY] == colorOfCell) {
                System.out.println("The big square is found.");
                return win = true;
            }
            System.out.println("Finish big square checker 1");
            System.out.println(" ");
            System.out.println("Start big square checker 2");
            if (moveChecker.moveValidator(coordinateX  + 2, coordinateY, gameBoard) &&
                    temporaryBoard[coordinateX + 2][coordinateY] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX + 2, coordinateY - 2, gameBoard) &&
                    temporaryBoard[coordinateX + 2][coordinateY - 2] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX, coordinateY  - 2, gameBoard) &&
                    temporaryBoard[coordinateX][coordinateY  - 2] == colorOfCell) {
                System.out.println("The big square is found.");
                return win = true;
            }
            System.out.println("Finish big square checker 2");
            System.out.println(" ");
            System.out.println("Start big square checker 3");
            if (moveChecker.moveValidator(coordinateX, coordinateY - 2, gameBoard) &&
                    temporaryBoard[coordinateX][coordinateY- 2] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX - 2, coordinateY - 2, gameBoard) &&
                    temporaryBoard[coordinateX - 2][coordinateY - 2] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX - 2, coordinateY, gameBoard) &&
                    temporaryBoard[coordinateX - 2][coordinateY] == colorOfCell) {
                System.out.println("The big square is found.");
                return win = true;
            }
            System.out.println("Finish big square checker 3");
            System.out.println(" ");
            System.out.println("Start big square checker 4");
            if (moveChecker.moveValidator(coordinateX  - 2, coordinateY, gameBoard) &&
                    temporaryBoard[coordinateX - 2][coordinateY] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX - 2, coordinateY + 2, gameBoard) &&
                    temporaryBoard[coordinateX - 2][coordinateY + 2] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX, coordinateY  + 2, gameBoard) &&
                    temporaryBoard[coordinateX][coordinateY  + 2] == colorOfCell) {
                System.out.println("The big square is found.");
                return win = true;
            }
            System.out.println("Finish big square checker 4");
            System.out.println("----------------------------------------------------------");

            //Rhombus checker:
            //_ _ o _ _
            //_ o _ o _
            //_ _ o _ _
            System.out.println("Start Rhombus checker 1");
            if (moveChecker.moveValidator(coordinateX + 1, coordinateY + 1, gameBoard) &&
                    temporaryBoard[coordinateX + 1][coordinateY + 1] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX + 2, coordinateY, gameBoard) &&
                    temporaryBoard[coordinateX + 2][coordinateY] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX + 1, coordinateY - 1, gameBoard) &&
                    temporaryBoard[coordinateX + 1][coordinateY - 1] == colorOfCell) {
                System.out.println("The rhombus is found.");
                return win = true;
            }
            System.out.println("Finish Rhombus checker 1");
            System.out.println(" ");
            System.out.println("Start Rhombus checker 2");
            if (moveChecker.moveValidator(coordinateX + 1, coordinateY - 1, gameBoard) &&
                    temporaryBoard[coordinateX + 1][coordinateY - 1] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX, coordinateY  - 2, gameBoard) &&
                    temporaryBoard[coordinateX][coordinateY - 2] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX - 1, coordinateY - 1, gameBoard) &&
                    temporaryBoard[coordinateX - 1][coordinateY - 1] == colorOfCell) {
                System.out.println("The rhombus is found.");
                return win = true;
            }System.out.println("Finish Rhombus checker 2");
            System.out.println(" ");
            System.out.println("Start Rhombus checker 3");
            if (moveChecker.moveValidator(coordinateX - 1, coordinateY - 1, gameBoard) &&
                    temporaryBoard[coordinateX - 1][coordinateY - 1] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX  - 2, coordinateY, gameBoard) &&
                    temporaryBoard[coordinateX  - 2][coordinateY] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX - 1, coordinateY + 1, gameBoard) &&
                    temporaryBoard[coordinateX - 1][coordinateY + 1] == colorOfCell) {
                System.out.println("The rhombus is found.");
                return win = true;
            }
            System.out.println("Finish Rhombus checker 3");
            System.out.println(" ");
            System.out.println("Start Rhombus checker 4");
            if (moveChecker.moveValidator(coordinateX - 1, coordinateY + 1, gameBoard) &&
                    temporaryBoard[coordinateX - 1][coordinateY + 1] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX, coordinateY + 2, gameBoard) &&
                    temporaryBoard[coordinateX][coordinateY + 2] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX + 1, coordinateY + 1, gameBoard) &&
                    temporaryBoard[coordinateX + 1][coordinateY + 1] == colorOfCell) {
                System.out.println("The rhombus is found.");
                return win = true;
            }
            System.out.println("Finish Rhombus checker 4");
            System.out.println("----------------------------------------------------------");



            //Tilted square checker:
            //_ _ _ o _ _
            //_ o _ _ _ _
            //_ _ _ _ o _
            //_ _ o _ _ _
            System.out.println("Start Tilted square checker 1");
            if (moveChecker.moveValidator(coordinateX - 1, coordinateY + 2, gameBoard) &&
                    temporaryBoard[coordinateX - 1][coordinateY + 2] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX + 1, coordinateY + 3, gameBoard) &&
                    temporaryBoard[coordinateX + 1][coordinateY + 3] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX + 2, coordinateY + 1, gameBoard) &&
                    temporaryBoard[coordinateX + 2][coordinateY + 1] == colorOfCell) {
                System.out.println("The tilted square is found.");
                return win = true;
            }
            System.out.println("Finish Tilted square checker 1");
            System.out.println(" ");
            System.out.println("Start Tilted square checker 2");
            if (moveChecker.moveValidator(coordinateX + 2, coordinateY + 1, gameBoard) &&
                    temporaryBoard[coordinateX + 2][coordinateY + 1] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX + 3, coordinateY - 1, gameBoard) &&
                    temporaryBoard[coordinateX + 3][coordinateY - 1] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX + 1, coordinateY - 2, gameBoard) &&
                    temporaryBoard[coordinateX + 1][coordinateY - 2] == colorOfCell) {
                System.out.println("The tilted square is found.");
                return win = true;
            }
            System.out.println("Finish Tilted square checker 2");
            System.out.println(" ");
            System.out.println("Start Tilted square checker 3");

            if (moveChecker.moveValidator(coordinateX + 1, coordinateY - 2, gameBoard) &&
                    temporaryBoard[coordinateX + 1][coordinateY - 2] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX - 1, coordinateY - 3, gameBoard) &&
                    temporaryBoard[coordinateX - 1][coordinateY - 3] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX - 2, coordinateY - 1, gameBoard) &&
                    temporaryBoard[coordinateX - 2][coordinateY - 1] == colorOfCell) {
                System.out.println("The tilted square is found.");
                return win = true;
            }

            System.out.println("Finish Tilted square checker 3");
            System.out.println(" ");
            System.out.println("Start Tilted square checker 4");

            if (moveChecker.moveValidator(coordinateX - 2, coordinateY - 1, gameBoard) &&
                    temporaryBoard[coordinateX - 2][coordinateY - 1] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX - 3, coordinateY + 1, gameBoard) &&
                    temporaryBoard[coordinateX - 3][coordinateY + 1] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX - 1, coordinateY + 2, gameBoard) &&
                    temporaryBoard[coordinateX - 1][coordinateY + 2] == colorOfCell) {

                System.out.println("The tilted square is found.");
                return win = true;
            }
            System.out.println("Finish Tilted square checker 4");
            System.out.println("----------------------------------------------------------");


            //Reverse tilted square checker:
            //_ _ o _ _ _
            //_ _ _ _ o _
            //_ o _ _ _ _
            //_ _ _ o _ _
            System.out.println("Start Reverse tilted square checker 1");
            if (moveChecker.moveValidator(coordinateX + 2, coordinateY - 1, gameBoard) &&
                    temporaryBoard[coordinateX + 2][coordinateY - 1] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX + 1, coordinateY - 3, gameBoard) &&
                    temporaryBoard[coordinateX + 1][coordinateY - 3] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX - 1, coordinateY - 2, gameBoard) &&
                    temporaryBoard[coordinateX - 1][coordinateY - 2] == colorOfCell) {
                System.out.println("The reverse tilted square is found.");
                return win = true;
            }

            System.out.println("Finish Reverse tilted square checker 1");
            System.out.println(" ");
            System.out.println("Start Tilted square checker 2");

            if (moveChecker.moveValidator(coordinateX - 1, coordinateY - 2, gameBoard) &&
                    temporaryBoard[coordinateX - 1][coordinateY - 2] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX - 3, coordinateY - 1, gameBoard) &&
                    temporaryBoard[coordinateX - 3][coordinateY - 1] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX - 2, coordinateY + 1, gameBoard) &&
                    temporaryBoard[coordinateX - 2][coordinateY + 1] == colorOfCell) {
                System.out.println("The reverse tilted square is found.");
                return win = true;
            }

            System.out.println("Finish Tilted square checker 2");
            System.out.println(" ");
            System.out.println("Start Tilted square checker 3");

            if (moveChecker.moveValidator(coordinateX - 2, coordinateY + 1, gameBoard) &&
                    temporaryBoard[coordinateX - 2][coordinateY + 1] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX - 1, coordinateY + 3, gameBoard) &&
                    temporaryBoard[coordinateX - 1][coordinateY + 3] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX - 2, coordinateY - 1, gameBoard) &&
                    temporaryBoard[coordinateX - 2][coordinateY - 1] == colorOfCell) {
                System.out.println("The reverse tilted square is found.");
                return win = true;
            }
            System.out.println("Finish Tilted square checker 3");
            System.out.println(" ");
            System.out.println("Start Tilted square checker 4");

            if (moveChecker.moveValidator(coordinateX + 1, coordinateY + 2, gameBoard) &&
                    temporaryBoard[coordinateX + 1][coordinateY + 2] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX + 3, coordinateY + 1, gameBoard) &&
                    temporaryBoard[coordinateX + 3][coordinateY + 1] == colorOfCell &&

                    moveChecker.moveValidator(coordinateX + 2, coordinateY - 1, gameBoard) &&
                    temporaryBoard[coordinateX + 2][coordinateY - 1] == colorOfCell) {
                System.out.println("The reverse tilted square is found.");
                return win = true;
            }
            System.out.println("Finish Tilted square checker 4");
            System.out.println("----------------------------------------------------------");
        }
        catch (Exception e){
        }

        return win;
    }
}

//"  w w  b   b b   b  w   w" - ромб чёрных
//
