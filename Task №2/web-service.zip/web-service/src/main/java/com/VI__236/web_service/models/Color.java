package com.VI__236.web_service.models;

public enum Color {
    WHITE, BLACK
}
